#pragma once
#ifndef RIGIDBODY_H
#define RIGIDBODY_H

#include "Entity.h"

class RigidBody: public Entity {

};

#endif